class AssetConstants {
  const AssetConstants._();

  static const String designPatternsJsonPath =
      'assets/data/design_patterns.json';
  static const String markdownPath = 'assets/markdown/';
}
