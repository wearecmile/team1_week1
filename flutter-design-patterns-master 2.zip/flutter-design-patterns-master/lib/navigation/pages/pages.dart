export 'design_pattern_details_page.dart';
export 'main_menu_page.dart';
