package com.mangirdaskazlauskas.flutter_design_patterns

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
